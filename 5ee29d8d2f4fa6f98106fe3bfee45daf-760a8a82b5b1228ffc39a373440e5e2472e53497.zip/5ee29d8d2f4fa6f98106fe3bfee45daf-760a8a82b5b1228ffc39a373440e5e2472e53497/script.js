$(document).ready(function(){ 
$("p").addClass("animated slideInLeft");
$(".box1").addClass("animated tada");
$(".box4").addClass("animated swing");
$(".box5").addClass("animated fadeInUpBig");
$(".box6").addClass("animated lightSpeedIn");
$(".box7").addClass("animated hinge");
$(".box8").addClass("animated zoomIn");
$(".box9").addClass("animated flash");
});